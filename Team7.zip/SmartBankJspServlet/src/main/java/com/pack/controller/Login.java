package com.pack.controller;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.pack.dao.UserDao;
import com.pack.models.UserModel;

/**
 * Servlet implementation class Login
 */
@WebServlet("/Login")
public class Login extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	UserDao userdao=new UserDao();
    public Login() {
        super();
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	
		String action = request.getParameter("action");
		System.out.println(action);
		switch (action) {
		case "admin":
			admin(request, response);
			break;
		case "user":
			user(request, response);
			break;
		}
		
		
	}

	private void user(HttpServletRequest request, HttpServletResponse response) throws IOException {
		
		UserModel userm=new UserModel();
		userm.setUserLoginId(request.getParameter("user_name"));
		userm.setUserPassword(request.getParameter("password"));
		
		int i=userdao.user(userm);
		if(i>0)
		{
			if(i==2)
			{
			response.sendRedirect("user.jsp");
			request.setAttribute("loginid",userm.getUserLoginId());
			}
			else if(i==3){
				response.sendRedirect("userpass.jsp");
			}
		}
	}

	private void admin(HttpServletRequest request, HttpServletResponse response) throws IOException {
		// TODO Auto-generated method stub
		UserModel userm=new UserModel();
		userm.setUserLoginId(request.getParameter("user_name"));
		userm.setUserPassword(request.getParameter("password"));
		
		int i=userdao.admin(userm);
		if(i>0)
		{
			if(userm.getUserLoginId().equals("Alan"))
			{
			response.sendRedirect("admin.jsp");
			}
		}
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
